#pragma once

void menu_display(const vector <Client> &client, const vector <Pack> &packs);

void menu_client(vector <Client> &clients,const vector <Pack> &packs);

