#pragma once


//#include "clients.hpp"

using namespace std;

string read_address(ifstream &file_read_obj);

void date_parsing(string date, int *ano, int *mes, int *dia);

